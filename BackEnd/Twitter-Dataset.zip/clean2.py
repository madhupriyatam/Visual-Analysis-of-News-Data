import pandas as pd
from geopy.geocoders import Nominatim
from geopy.exc import GeocoderTimedOut

from geotext import GeoText


data = pd.read_csv("Articles.csv", encoding = "ISO-8859-1") 
# Preview the first 5 lines of the loaded data 

#print(data['Article'])

data['Location'] = "Nan"
data['Longitude'] = ""
data["Latitude"] = ""
data['Un'] = ""
count = 0
count1 = 0
for row in data.iterrows():
	#print(row[1]['Article'][:50])
	if ":" not in row[1]['Article'][:50]:
		
		#print(row[1]) 
		continue
	row[1]['Location'], row[1]['Article'] = row[1]['Article'].split(':', 1)
	# print(row[1])

	if "strong>" not in row[1]['Location']:
		#print(row[1]['Location'])
		continue
	row[1]['Un'], row[1]['Location'] = row[1]['Location'].split('>', 1)
	#print(row[1]['Location'])

for row in data.iterrows():
	if "," not in row[1]['Location']:
		count = count +1 
		#print(row[1]['Location'])
		continue
	count1 = count1 +1 
	row[1]['Location'], row[1]['Un'] = row[1]['Location'].split(',', 1)
	#print(row[1]['Location'])
	#print(row[1]['Article'])

print(count)
for row in data.iterrows():
	if "/" not in row[1]['Location']:
		count = count +1 
		#print(row[1]['Location'])
		continue
	count1 = count1 +1 
	row[1]['Location'], row[1]['Un'] = row[1]['Location'].split('/', 1)
print(count1)

# for row in data.iterrows():
# 	print(row[1]['Location'])

geolocator = Nominatim(user_agent="suryateja2197")
location = geolocator.geocode("HONG KONG")
print((location.latitude, location.longitude))

# places = GeoText("London is a great city")
# print(places.cities)

# for row in data.iterrows():
# 	if "Nan"  not in row[1]['Location']:
# 		continue
# 	places = GeoText(row[1]['Article'])
# 	print(places.cities)

# data1 = data[0:10]
# #print(data)
# print(data1)
# data1["Longitude"] = geolocator.geocode("HONG KONG", timeout=None)
# print(data1["Longitude"])

for row in data.iterrows():
	if "Nan"  in row[1]['Location']:
		continue
	#print(row[1]['Location'])
	try:
		location = geolocator.geocode(row[1]['Location'], timeout=None)
	except GeocoderTimedOut:
		continue
	if location is not None:
		if location.latitude is not None:
			#print("surya")
			row[1]['Latitude'] = location.latitude
		if location.longitude is not None:
			#print("tej")
			row[1]['Longitude'] = location.longitude
	#print((location.latitude, location.longitude))



data.to_csv('result.csv', encoding='utf-8')