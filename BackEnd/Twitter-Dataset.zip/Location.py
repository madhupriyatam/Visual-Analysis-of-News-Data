import pandas as pd
from itertools import chain
import numpy as np

data_location = pd.read_csv("Location.csv", encoding = "ISO-8859-1")
col_list = ["Document", "Longitude", "Latitude"]
data_location = data_location[col_list]

data_entity = pd.read_csv("result_NET.csv", encoding = "ISO-8859-1")

print(data_location)
print(data_entity)
data_entity = data_entity.join(data_location.set_index('Document'), on='Document')
print(data_entity)
data_entity.to_csv('Location.csv', encoding='utf-8')