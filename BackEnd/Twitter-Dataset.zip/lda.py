import pandas as pd
data = pd.read_csv('Tweets.csv', error_bad_lines=False);
data_text = data[['Tweet Text']]
data_text['index'] = data_text.index
documents = data_text
#laoding the csv file and putting it in documents

print(len(documents))
print(documents[:5])

import gensim
from gensim.utils import simple_preprocess
from gensim.parsing.preprocessing import STOPWORDS
from nltk.stem import WordNetLemmatizer, SnowballStemmer
from nltk.stem.porter import *
import numpy as np
np.random.seed(2018)
import nltk
nltk.download('wordnet')

#preprocessing data

stemmer = SnowballStemmer('english')
def lemmatize_stemming(text):
    return stemmer.stem(WordNetLemmatizer().lemmatize(text, pos='v'))
def preprocess(text):
    result = []
    for token in gensim.utils.simple_preprocess(str(text)):
        if token not in gensim.parsing.preprocessing.STOPWORDS and len(token) > 3:
            result.append(lemmatize_stemming(token))
    return result

doc_sample = documents[documents['index'] == 10].values[0][0]
print('original document: ')
words = []
for word in doc_sample.split(' '):
    words.append(word)
print(words)
print('\n\n tokenized and lemmatized document: ')
print(preprocess(doc_sample))

processed_docs = documents['Tweet Text'].map(preprocess)
#printing pre-processed data into the file
import json

with open('preprocess.txt', 'w') as f:
    for key, value in processed_docs.items():
        f.write('%s:%s\n' % (key, value))
#print end
print(processed_docs[:10])



print("------------------------from here----------------------------------------------")


dictionary = gensim.corpora.Dictionary(processed_docs)
count = 0
for k, v in dictionary.iteritems():
    print(k, v)
    count += 1
    if count > 10:
        break

dictionary.filter_extremes(no_below=15, no_above=0.5, keep_n=100000)
#      file.write(json.dumps(dictionary_dict))

with open('dictionary.txt', 'w') as f:
    for key, value in dictionary.items():
        f.write('%s:%s\n' % (key, value.encode('utf-8')))
#print end

bow_corpus = [dictionary.doc2bow(doc) for doc in processed_docs]


with open('bow_corpus_dict.txt', 'w') as f:
    for value in bow_corpus:
        f.write('%s, \n' % value)
#print end
bow_corpus[10]

bow_doc_4310 = bow_corpus[10]
for i in range(len(bow_doc_4310)):
    print("Word {} (\"{}\") appears {} time.".format(bow_doc_4310[i][0], 
                                               dictionary[bow_doc_4310[i][0]], 
bow_doc_4310[i][1]))
# TFIDF model
from gensim import corpora, models
tfidf = models.TfidfModel(bow_corpus)
corpus_tfidf = tfidf[bow_corpus]
from pprint import pprint
for doc in corpus_tfidf:
    pprint(doc)
    break
#-----------------------------------------------------------------------------------------------

#printing tfidf corpus

with open('tfidf_corpus.txt', 'w') as f:
    for value in corpus_tfidf:
        f.write('%s \n' % (value))

lda_model_tfidf = gensim.models.LdaModel(corpus_tfidf, num_topics=25, id2word=dictionary, passes=2)

print("---------------------------hellinger distance--------------------------------------")

import numpy as np
from scipy.spatial.distance import pdist, squareform

def hellinger(X):
    return squareform(pdist(np.sqrt(X)))/np.sqrt(2)

# lda = LdaModel(corpus, num_topics=10)
X = lda_model_tfidf.state.get_lambda()
X = X / X.sum(axis=1)[:, np.newaxis] # normalize vector
h = hellinger(X)

with open('hellinger.txt', 'w') as f:
    for value in h:
        f.write('%s, \n' % value)

lda_topics_list = []
for i in  lda_model_tfidf.show_topics(num_topics=25):
    lda_topics_list.append(i[1])
    print i[0], i[1]

h = h.tolist()
topic_similarity_list = [x for x in h[0]]
# print type(h[0][0])
# h = [[x.encode('UTF8') for x in i] for i in h]
topic_similarity_list_index = 0
ranked_topics = []
ranked_topics.append(lda_topics_list[0])

print topic_similarity_list
print ranked_topics
print("---------------------------------------helinger ends----------------------------")

min_index = 0
# prev_min_index = 0
min_index_list = [0]

for i in range(24):
    # print topic_similarity_list
    # print "hiii" + str(len(topic_similarity_list))
    min_value = 1.1
    for j in range(25):
        if (topic_similarity_list[j] != 0) and (j not in min_index_list) and (topic_similarity_list[j] < min_value):
            min_value = topic_similarity_list[j]
            min_index = j

    topic_similarity_list = [x for x in h[min_index]]
    min_index_list.append(min_index)
    ranked_topics.append(lda_topics_list[min_index])

print min_index_list
print ranked_topics

ranked_topic_map = {}
for i in range(25):
    ranked_topic_map[i] = ranked_topics[i]

import csv
# ranked_topic_map_csv = ['Topic', 'Word', 'Frequency'] 
with open('topic_cloud.csv', 'wb') as csv_file:
    writer = csv.writer(csv_file)
    writer.writerow(['Topic', 'Word', 'Frequency'])
    for key, value in ranked_topic_map.items():
        for words in value.split("+"):
            freq, word = words.split("*")
            writer.writerow([key, str(word), freq])

import json
with open('topic_cloud.json', 'w') as fp:
    json.dump(ranked_topic_map, fp)

#end helinger

lda_corpus = lda_model_tfidf[corpus_tfidf]

# print lda_corpus

print(type(lda_corpus))
# for topic in lda_corpus:
print(lda_corpus[0])
print(lda_corpus[0][0])
print(lda_corpus[1])
print(lda_corpus[2])

print(len(lda_corpus))

from itertools import chain

# Find the threshold, let's set the threshold to be 1/#clusters,
# To prove that the threshold is sane, we average the sum of all probabilities:
scores = list(chain(*[[score for topic_id,score in topic] \
                      for topic in [doc for doc in lda_corpus]]))

# print scores
threshold = sum(scores)/len(scores)
print threshold
print

document_topic_map = {}
doc_id = 0
for doc in lda_corpus:
    max_prob = -1
    for tup in doc:
        if (tup[1] > threshold) and (tup[1] > max_prob) :
            max_prob = tup[1]
            max_topic_id = tup[0]
                    
    document_topic_map[doc_id] = min_index_list.index(max_topic_id)
    # document_topic_map[doc_id] = max_topic_id
    doc_id = doc_id + 1

# print document_topic_map
print(len(document_topic_map))

# document_topic_map csv
# import csv

with open('doc_topic_map.csv', 'wb') as csv_file:
    writer = csv.writer(csv_file)
    for key, value in document_topic_map.items():
       writer.writerow([key, value])


# document_topic_map json
# import json
with open('doc_topic_map.json', 'w') as fp:
    json.dump(document_topic_map, fp)


log_file = open('/home/nruthviik/lda_model_tfidf_dict.txt', 'w')
print>>log_file, lda_model_tfidf.show_topics(num_topics=25)

for idx, topic in lda_model_tfidf.print_topics(-1):
    print('Topic: {} Word: {}'.format(idx, topic))

processed_docs[10]