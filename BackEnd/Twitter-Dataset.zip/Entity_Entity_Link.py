import pandas as pd
from itertools import chain
import numpy as np
import json

data_topic_map = pd.read_csv("Document_Entity.csv", encoding = "ISO-8859-1")

df_empty = pd.DataFrame({'Source' : [], 'Destination': [], 'Count': []})

for row in data_topic_map.iterrows():
	# print(row)
	str1 = row[1]['Entities'][1:-1]
	if "," not in str1: 
		continue
	list1 = [x.strip() for x in str1.split(',')]
	# print(list1)
	for i in range(len(list1) - 1):
		for j in range(i, len(list1)):
			df_empty = df_empty.append({'Source': list1[i], 'Destination': list1[j], 'Count': 0}, ignore_index=True)
df_empty['Count'] = df_empty['Count'].astype(int)
df_empty = df_empty.loc[df_empty['Source'] != df_empty['Destination']]

# print(df_empty)

df_drop_duplicates = df_empty.drop_duplicates()
print(df_drop_duplicates)

for row1 in df_drop_duplicates.iterrows():
	print(row1[0])
	for row2 in df_empty.iterrows():
		if row1[1]['Source'] == row2[1]['Source'] and row1[1]['Destination'] == row2[1]['Destination']:
			df_drop_duplicates["Count"][row1[0]] = df_drop_duplicates["Count"][row1[0]] + 1
			# row1[1]['Count'] = row1[1]['Count'] + 1
# data["Entities"][row[0]] 

df_drop_duplicates_final = df_drop_duplicates.loc[df_drop_duplicates['Count'] > 1]
# print(df_drop_duplicates_final)
# for row in df_empty.iterrows():
# 	print(row[1]['Source'])

df_entity = pd.DataFrame({'name' : []})
df_entity['name'] = df_drop_duplicates_final ['Source']
df_entity1 = pd.DataFrame({'name' : []})
df_entity1['name'] = df_drop_duplicates_final ['Destination']
frames = [df_entity, df_entity1]
df_entity = pd.concat(frames)
df_entity = df_entity.drop_duplicates()
df_entity.index = range(df_entity.shape[0])
df_entity['group'] = df_entity.index
# df_entity['group'] = df_entity['group'].astype(str)
# print(df_entity)

df_entity = df_entity.rename(index=str, columns={"name": "Source"})
df_drop_duplicates_final = df_drop_duplicates_final.join(df_entity.set_index('Source'), on='Source')
df_drop_duplicates_final = df_drop_duplicates_final.drop(columns=['Source'])
df_drop_duplicates_final = df_drop_duplicates_final.rename(index=str, columns={"group": "source"})
df_entity = df_entity.rename(index=str, columns={"Source": "Destination"})
df_drop_duplicates_final = df_drop_duplicates_final.join(df_entity.set_index('Destination'), on='Destination')
df_drop_duplicates_final = df_drop_duplicates_final.drop(columns=['Destination'])
df_drop_duplicates_final = df_drop_duplicates_final.rename(index=str, columns={"group": "destination", "Count": "value"})

df_entity = df_entity.rename(index=str, columns={"Destination": "name"})


print(df_drop_duplicates_final)
# pandas_df = df_entity.toPandas()
jason = df_entity.to_json(orient='records')
print(jason)
# jason.to_json('Nodes.json')

jason = df_drop_duplicates_final.to_json(orient='records')
print(jason)
# jason.to_json('Nodes.json')

# print(type(jason))
# with open('Nodes.json','w') as outfile:
# 	json.dump(jason, outfile) 