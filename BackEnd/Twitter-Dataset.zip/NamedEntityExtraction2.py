# -*- coding: utf-8 -*-
import pandas as pd
import json
from nltk.tag import StanfordNERTagger
from nltk.tokenize import word_tokenize
from geopy.geocoders import Nominatim
from geopy.exc import GeocoderTimedOut
from geopy.extra.rate_limiter import RateLimiter
geocode = RateLimiter(geolocator.geocode, min_delay_seconds=1)

from geotext import GeoText

st = StanfordNERTagger('stanford-ner-tagger/english.all.3class.distsim.crf.ser.gz',
					   'stanford-ner-tagger/stanford-ner-3.9.2.jar',
					   encoding='utf-8')

text = 'San Francisco & New York City'


tokenized_text = word_tokenize(text)
classified_text = st.tag(tokenized_text)

print(classified_text)
geolocator = Nominatim(user_agent="suryateja2197")
location = geolocator.geocode("San Francisco & New York City")
print((location.latitude, location.longitude))
location = geolocator.geocode("York")
print((location.latitude, location.longitude))

# #Classifier_words = ner_tagger.tag(words)
# #Classifier_words1 = [t for t in classified_text if t[1]=='LOCATION']
# Classifier_words1 = [t for t in classified_text if t[1]=='PERSON']
# print(Classifier_words1)
# Entities = [x[0] for x in Classifier_words1]
# print(Entities)

# #values = ['a', 'b', 'a']
# #set = set(values)
# # result = list(set)
# # print(result)
# count = 0
data = pd.read_csv("result_NET.csv", encoding = "ISO-8859-1")
# data['Entities'] = ""
data['Longitude'] = ""
data["Latitude"] = ""
# print(data[0]['Article'])
# data = data.loc[data['Location'] != 'NaN']
data = data.dropna(subset=['Location'])
print(data['Location'])
count = 0 
for row in data.iterrows():
	#print(row[1]['Article'])
	print(count)
	# tokenized_text = word_tokenize(row[1]['Location'])
	# classified_text = st.tag(tokenized_text)
	# Classifier_words1 = [t for t in classified_text if t[1]=='LOCATION']
	# print(classified_text)
	# Entities = [x[0] for x in Classifier_words1]
	# if(Entities):
	if(row[1]['Location']):
		# print(row[1]['Location'])
		try:
			location = geocode(row[1]['Location'], timeout=None)
		except GeocoderTimedOut:
			continue
		if location is not None:
			if location.latitude is not None:
				#print("surya")
				# row[1]['Latitude'] = location.latitude
				data["Latitude"][row[0]] = location.latitude
				# print(location.latitude)
			if location.longitude is not None:
				#print("tej")
				# row[1]['Longitude'] = location.longitude
				data["Longitude"][row[0]] = location.longitude
				# print(location.longitude)
	count = count + 1
	# if(count == 15):
	# 	break
print(data)
	# set1 = set(Entities)
	# Entities = list(set1)
	# # row[1]['Entities'] = 1
	# data["Entities"][row[0]] = Entities
	# #data[row[0]][1]['Entities'] = Entities
	# #print(data[0])
	# print(data["Entities"][row[0]])
	#print(row[0])
	#print(row[1])


# print(data)
# print(data["Entities"][1])
data.to_csv('Location.csv', encoding='utf-8')
# jason = data.to_json(orient='records')
# print(type(jason))
# with open('result_NET.json','w') as outfile:
# 	json.dump(jason, outfile) 